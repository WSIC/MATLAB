/*****************************
// NDPRead.h - NDP data access library
// (c) Copyright 2011 Hamamatsu Photonics K.K.
// Version 1.1.32
//***************************/

#define NDPREAD_CHANNELORDER_UNDEFINED	(0)
#define NDPREAD_CHANNELORDER_BGR		(1)
#define NDPREAD_CHANNELORDER_RGB		(2)
#define NDPREAD_CHANNELORDER_Y			(3)

extern "C"
{
	typedef struct
	{
		unsigned long	nSize;	/* Set to sizeof(GetImageDataExParams) */
		long			nPhysicalXPos;
		long			nPhysicalYPos;
		long			nPhysicalZPos;
		float			fMag;
		long			nPixelWidth;
		long			nPixelHeight;
		long			nPhysicalWidth;
		long			nPhysicalHeight;
		void		   *pBuffer;
		long			nBufferSize;
	} GetImageDataExParams;
	
	typedef struct
	{
		unsigned long	nSize;	/* Set to sizeof(GetMapExParams) */
		long			nPixelWidth;
		long			nPixelHeight;
		long			nPhysicalX;
		long			nPhysicalY;
		long			nPhysicalWidth;
		long			nPhysicalHeight;
		void		   *pBuffer;
		long			nBufferSize;
	} GetMapExParams;
	
	long	GetImageWidthW(LPCWSTR i_strImageID);
	long	GetImageHeightW(LPCWSTR i_strImageID);
	long	GetImageBitDepthW(LPCWSTR i_strImageID);
	long	GetNoChannelsW(LPCWSTR i_strImageID);
	long	GetChannelOrderW(LPCWSTR i_strImageID);
	long	GetImageDataW(LPCWSTR i_strImageID, long i_nPhysicalXPos, long i_nPhysicalYPos, long i_nPhysicalZPos, float i_fMag, long *o_nPhysicalWidth, long *o_nPhysicalHeight, void *i_pBuffer, long *io_nBufferSize);
	long	GetImageDataExW(LPCWSTR i_strImageID, GetImageDataExParams *i_pParams);
	long	GetImageData16W(LPCWSTR i_strImageID, long i_nPhysicalXPos, long i_nPhysicalYPos, long i_nPhysicalZPos, float i_fMag, long *o_nPhysicalWidth, long *o_nPhysicalHeight, void *i_pBuffer, long *io_nBufferSize);
	long	GetImageDataInSourceBitDepthW(LPCWSTR i_strImageID, long i_nPhysicalXPos, long i_nPhysicalYPos, long i_nPhysicalZPos, float i_fMag, long *o_nPhysicalWidth, long *o_nPhysicalHeight, void *i_pBuffer, long *io_nBufferSize);
	long	GetImageDataInSourceBitDepthExW(LPCWSTR i_strImageID, GetImageDataExParams *i_pParams);
	float	GetSourceLensW(LPCWSTR i_strImageID);
	long	GetSourcePixelSizeW(LPCWSTR i_strImageID, long *o_nWidth, long *o_nHeight);
	long	GetReferenceW(LPCWSTR i_strImageID, LPWSTR o_strReference, long i_nBufferLength);
	long	GetMapW(LPCWSTR i_strImageID, long *o_nPhysicalX, long *o_nPhysicalY, long *o_nPhysicalWidth, long *o_nPhysicalHeight, void *i_pBuffer, long *io_nBufferSize, long *o_nPixelWidth, long *o_nPixelHeight);
	long	GetMapExW(LPCWSTR i_strImageID, GetMapExParams *i_pParams);
	long	GetSlideImageW(LPCWSTR i_strImageID, long *o_nPhysicalX, long *o_nPhysicalY, long *o_nPhysicalWidth, long *o_nPhysicalHeight, void *i_pBuffer, long *io_nBufferSize, long *o_nPixelWidth, long *o_nPixelHeight);
	long	GetZRangeW(LPCWSTR i_strImageID, long *o_nMin, long *o_nMax, long *o_nStep);
	LPCWSTR	GetLastErrorMessageW();
	long	GetLowLevelParamW(LPCWSTR i_strImageID, LPCWSTR i_strParamID, LPWSTR o_strValue, long i_nBufferLength);
	long	SetLowLevelParamW(LPCWSTR i_strImageID, LPCWSTR i_strParamID, LPCWSTR i_strParamValue);
	
	long	GetImageWidth(LPCSTR i_strImageID);
	long	GetImageHeight(LPCSTR i_strImageID);
	long	GetImageBitDepth(LPCSTR i_strImageID);
	long	GetNoChannels(LPCSTR i_strImageID);
	long	GetChannelOrder(LPCSTR i_strImageID);
	long	GetMap(LPCSTR i_strImageID, long *o_nPhysicalX, long *o_nPhysicalY, long *o_nPhysicalWidth, long *o_nPhysicalHeight, void *i_pBuffer, long *io_nBufferSize, long *o_nPixelWidth, long *o_nPixelHeight);
	long	GetMapEx(LPCSTR i_strImageID, GetMapExParams *i_pParams);
	long	GetSlideImage(LPCSTR i_strImageID, long *o_nPhysicalX, long *o_nPhysicalY, long *o_nPhysicalWidth, long *o_nPhysicalHeight, void *i_pBuffer, long *io_nBufferSize, long *o_nPixelWidth, long *o_nPixelHeight);
	long	GetZRange(LPCSTR i_strImageID, long *o_nMin, long *o_nMax, long *o_nStep);
	long	GetImageData(LPCSTR i_strImageID, long i_nPhysicalXPos, long i_nPhysicalYPos, long i_nPhysicalZPos, float i_fMag, long *o_nPhysicalWidth, long *o_nPhysicalHeight, void *i_pBuffer, long *io_nBufferSize);
	long	GetImageDataEx(LPCSTR i_strImageID, GetImageDataExParams *i_pParams);
	long	GetImageData16(LPCSTR i_strImageID, long i_nPhysicalXPos, long i_nPhysicalYPos, long i_nPhysicalZPos, float i_fMag, long *o_nPhysicalWidth, long *o_nPhysicalHeight, void *i_pBuffer, long *io_nBufferSize);
	long	GetImageDataInSourceBitDepth(LPCSTR i_strImageID, long i_nPhysicalXPos, long i_nPhysicalYPos, long i_nPhysicalZPos, float i_fMag, long *o_nPhysicalWidth, long *o_nPhysicalHeight, void *i_pBuffer, long *io_nBufferSize);
	long	GetImageDataInSourceBitDepthEx(LPCSTR i_strImageID, GetImageDataExParams *i_pParams);
	float	GetSourceLens(LPCSTR i_strImageID);
	long	GetSourcePixelSize(LPCSTR i_strImageID, long *o_nWidth, long *o_nHeight);
	long	GetReference(LPCSTR i_strImageID, LPSTR o_strReference, long i_nBufferLength);
	LPCSTR	GetLastErrorMessage();
	long	GetLowLevelParam(LPCSTR i_strImageID, LPCSTR i_strParamID, LPSTR o_strValue, long i_nBufferLength);
	long	SetLowLevelParam(LPCSTR i_strImageID, LPCSTR i_strParamID, LPCSTR i_strParamValue);
	
	long	SetCameraResolution(long i_nWidth, long i_nHeight);
	long	CleanUp();
	long	SetOption(long i_nOptionID, long i_nOptionValue);
}
